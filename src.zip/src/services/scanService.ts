import fs from "node:fs/promises";
import path from "node:path";
import type { TechStack } from "@/src/types/audit";

export type ScannedFile = {
  absolutePath: string;
  relativePath: string;
  fileSizeBytes: number;
};

export type ScanResult = {
  files: ScannedFile[];
  techStack: TechStack[];
  warnings: string[];
  filesSkipped: number;
};

const CODE_EXTENSIONS = new Set([".js", ".jsx", ".ts", ".tsx"]);
const IGNORED_DIRECTORIES = new Set([
  ".git",
  ".next",
  "build",
  "coverage",
  "dist",
  "node_modules",
]);
const MAX_FILE_COUNT = 250;
const MAX_FILE_SIZE_BYTES = 300_000;

function normalizeRelativePath(value: string) {
  return value.split(path.sep).join("/");
}

export async function scanRepository(repoPath: string): Promise<ScanResult> {
  const files: ScannedFile[] = [];
  const detectedStack = new Set<TechStack>();
  const warnings: string[] = [];
  let filesSkipped = 0;
  let limitReached = false;
  let packageJsonDetected = false;

  async function walk(currentPath: string) {
    if (limitReached) {
      return;
    }

    const entries = await fs.readdir(currentPath, { withFileTypes: true });

    for (const entry of entries) {
      if (limitReached) {
        return;
      }

      const entryPath = path.join(currentPath, entry.name);

      if (entry.isDirectory()) {
        if (IGNORED_DIRECTORIES.has(entry.name)) {
          filesSkipped += 1;
          continue;
        }

        await walk(entryPath);
        continue;
      }

      if (entry.name === "package.json") {
        packageJsonDetected = true;
      }

      const extension = path.extname(entry.name);

      if (!CODE_EXTENSIONS.has(extension)) {
        continue;
      }

      if (files.length >= MAX_FILE_COUNT) {
        limitReached = true;
        warnings.push(`Stopped scanning after ${MAX_FILE_COUNT} code files to protect runtime stability.`);
        return;
      }

      const stats = await fs.stat(entryPath);

      if (stats.size > MAX_FILE_SIZE_BYTES) {
        filesSkipped += 1;
        warnings.push(
          `Skipped ${normalizeRelativePath(path.relative(repoPath, entryPath))} because it exceeds ${MAX_FILE_SIZE_BYTES / 1000} KB.`,
        );
        continue;
      }

      files.push({
        absolutePath: entryPath,
        relativePath: normalizeRelativePath(path.relative(repoPath, entryPath)),
        fileSizeBytes: stats.size,
      });

      if (extension === ".js") {
        detectedStack.add("javascript");
      }

      if (extension === ".ts") {
        detectedStack.add("typescript");
      }

      if (extension === ".jsx") {
        detectedStack.add("javascript");
        detectedStack.add("react");
      }

      if (extension === ".tsx") {
        detectedStack.add("typescript");
        detectedStack.add("react");
      }
    }
  }

  await walk(repoPath);

  if (packageJsonDetected && detectedStack.size > 0) {
    detectedStack.add("nodejs");
  }

  return {
    files,
    techStack: Array.from(detectedStack),
    warnings,
    filesSkipped,
  };
}
