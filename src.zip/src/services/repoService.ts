import fs from "node:fs/promises";
import path from "node:path";
import simpleGit from "simple-git";

const TMP_ROOT = path.join(process.cwd(), ".stackaudit-tmp", "audits");

function sanitizeRepoName(value: string) {
  return value.replace(/[^a-zA-Z0-9-_]/g, "-").replace(/-+/g, "-");
}

export function getRepoNameFromUrl(repoUrl: string) {
  try {
    const url = new URL(repoUrl);
    const slug = url.pathname.split("/").filter(Boolean).pop() ?? "repository";
    return sanitizeRepoName(slug.replace(/\.git$/, "")) || "repository";
  } catch {
    throw new Error("Invalid repository URL.");
  }
}

export async function cloneRepository(repoUrl: string) {
  const repoName = getRepoNameFromUrl(repoUrl);
  const repoPath = path.join(TMP_ROOT, `${repoName}-${Date.now()}`);

  await fs.mkdir(TMP_ROOT, { recursive: true });

  const git = simpleGit();
  await git.clone(repoUrl, repoPath, ["--depth", "1", "--single-branch"]);

  return { repoName, repoPath };
}

export async function cleanupRepository(repoPath: string) {
  await fs.rm(repoPath, { recursive: true, force: true });
}
