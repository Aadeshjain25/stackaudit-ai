import Link from "next/link";
import { ArrowRight, Gauge, GitBranch, ShieldCheck, Sparkles } from "lucide-react";

const highlights = [
  { icon: ShieldCheck, text: "Static-first analysis" },
  { icon: Gauge, text: "Clear health scoring" },
  { icon: Sparkles, text: "Readable AI summary" },
];

const pillars = [
  {
    title: "Reliable scanning",
    detail: "Ignores generated folders, applies scan limits, and keeps audits stable on real repositories.",
    icon: GitBranch,
  },
  {
    title: "Useful scoring",
    detail: "One score backed by deterministic metrics so teams can prioritize risk quickly.",
    icon: Gauge,
  },
  {
    title: "Grounded reporting",
    detail: "AI explains findings instead of inventing them, which makes results easier to trust.",
    icon: Sparkles,
  },
];

export default function Home() {
  return (
    <main className="page-shell">
      <section className="page-grid">
        <div className="surface px-6 py-8 sm:px-8 sm:py-9">
          <span className="window-ornament" aria-hidden="true" />
          <span className="window-grid" aria-hidden="true" />

          <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-end">
            <div className="relative z-10">
              <h1 className="max-w-3xl text-3xl font-semibold tracking-tight text-white sm:text-4xl">
                Audit GitHub repositories with a cleaner view of code health.
              </h1>
              <p className="section-copy mt-4 max-w-2xl">
                StackAudit scans the repo, surfaces issues, ranks risky files, explains the results,
                and saves everything to a dashboard developers can actually use.
              </p>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link href="/analyze" className="cta-button">
                  Start audit
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  href="/dashboard"
                  className="inline-flex items-center gap-2 rounded-full border border-white/12 bg-white/[0.03] px-5 py-3 text-sm font-medium text-slate-100 hover:border-cyan-300/40 hover:bg-white/[0.06]"
                >
                  Open dashboard
                </Link>
              </div>
            </div>

            <div className="grid gap-3">
              {highlights.map(({ icon: Icon, text }) => (
                <div
                  key={text}
                  className="flex items-center gap-3 rounded-2xl border border-white/8 bg-white/[0.04] px-4 py-3 text-sm text-slate-200"
                >
                  <div className="rounded-full border border-cyan-400/20 bg-cyan-400/10 p-2">
                    <Icon className="h-4 w-4 text-cyan-200" />
                  </div>
                  {text}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="grid gap-4 lg:grid-cols-3">
          {pillars.map(({ title, detail, icon: Icon }) => (
            <article key={title} className="surface px-6 py-6 sm:px-7">
              <span className="window-ornament" aria-hidden="true" />
              <div className="relative z-10">
                <div className="mb-4 inline-flex rounded-2xl border border-white/10 bg-white/[0.04] p-3">
                  <Icon className="h-5 w-5 text-cyan-200" />
                </div>
                <h2 className="text-lg font-semibold text-white">{title}</h2>
                <p className="section-copy mt-3">{detail}</p>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
