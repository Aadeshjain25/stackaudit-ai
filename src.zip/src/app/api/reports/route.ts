import { NextResponse } from "next/server";
import { listReports } from "@/src/services/reportService";

export async function GET() {
  try {
    const reports = await listReports();
    return NextResponse.json(reports);
  } catch (error) {
    console.error(error);
    return NextResponse.json(
      { message: "Database error" },
      { status: 500 }
    );
  }
}
