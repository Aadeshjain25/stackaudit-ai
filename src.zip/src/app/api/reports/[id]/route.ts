import { NextResponse } from "next/server";
import { getReportById } from "@/src/services/reportService";

type Params = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(_request: Request, { params }: Params) {
  try {
    const { id } = await params;
    const report = await getReportById(Number(id));

    if (!report) {
      return NextResponse.json({ error: "Report not found" }, { status: 404 });
    }

    return NextResponse.json(report);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: "Unable to load report" }, { status: 500 });
  }
}
