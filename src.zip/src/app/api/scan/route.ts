import { NextResponse } from "next/server";
import { runAudit, UnsupportedRepoError } from "@/src/services/auditService";

export async function POST(req: Request) {
  try {
    const { repoUrl } = await req.json();

    if (!repoUrl || typeof repoUrl !== "string") {
      return NextResponse.json(
        { error: "Repository URL required" },
        { status: 400 }
      );
    }

    const result = await runAudit(repoUrl);

    return NextResponse.json(result);

  } catch (error) {
    console.error("SCAN ERROR:", error);

    if (error instanceof UnsupportedRepoError) {
      return NextResponse.json(
        {
          success: false,
          error: "UNSUPPORTED_REPO",
          message: error.message,
        },
        { status: 422 },
      );
    }

    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Internal Server Error",
      },
      { status: 500 }
    );
  }
}
